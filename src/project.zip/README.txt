Program setup:
1. Import tableBustersDB.sql into your mysql server
2. compile application: $ javac DatabaseApp.java
3. execute application: $ java -cp :mysql-connector-java-5.1.47.jar: DatabaseApp

